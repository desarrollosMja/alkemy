export const config = {
    BACK_PORT: process.env.REACT_APP_BACK_PORT
}